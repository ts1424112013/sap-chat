import fs from 'node:fs/promises';import path from 'node:path';
const root='/Users/tangtang/Desktop/AIProject/sap-chat/.codex-build-lingxi/redesign';
const src=path.join(root,'outputs/html_weights_explained');
const dst=path.join(root,'outputs/html_faq_before_lingxi');
await fs.mkdir(dst,{recursive:true});
const order=[...Array.from({length:16},(_,i)=>i+1),23,24,25,26,17,18,19,20,21,22];
for(let i=0;i<order.length;i++){
  const old=order[i],now=i+1;
  let html=await fs.readFile(path.join(src,`slide_${String(old).padStart(2,'0')}.html`),'utf8');
  html=html.replace(/<span>\d{2} \/ 26<\/span>/,`<span>${String(now).padStart(2,'0')} / 26</span>`);
  if(old===25) html=html.replace('Q4 / AGI & CONSCIOUSNESS','Q3 / AGI & CONSCIOUSNESS');
  if(old===26) html=html.replace('Q5 / US & CHINA','Q4 / US & CHINA');
  await fs.writeFile(path.join(dst,`slide_${String(now).padStart(2,'0')}.html`),html);
}
console.log('reordered:',order.join(','));
