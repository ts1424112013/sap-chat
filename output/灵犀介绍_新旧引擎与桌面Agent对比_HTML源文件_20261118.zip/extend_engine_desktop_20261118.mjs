import fs from 'node:fs/promises';
import path from 'node:path';

const root = '/Users/tangtang/Desktop/AIProject/sap-chat/.codex-build-lingxi/redesign';
const source = path.join(root, 'outputs/html_nomi_positioning');
const target = path.join(root, 'outputs/html_engine_desktop_20261118');
await fs.mkdir(target, { recursive: true });

const sample = await fs.readFile(path.join(source, 'slide_21.html'), 'utf8');
const css = sample.match(/<style>([\s\S]*?)<\/style>/)[1];

function shell(number, content) {
  return `<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=1600"><style>${css}</style></head><body><section class="slide"><i class="crop tl"></i><i class="crop tr"></i><i class="crop bl"></i><i class="crop br"></i><main class="main-frame">${content}</main><div class="footer"><span>LINGXI / SAP AI</span><span>${String(number).padStart(2, '0')} / 32</span></div></section></body></html>`;
}

async function copySlide(from, to) {
  let html = await fs.readFile(path.join(source, `slide_${String(from).padStart(2, '0')}.html`), 'utf8');
  html = html.replace(/<span>\d{2} \/ 28<\/span>/, `<span>${String(to).padStart(2, '0')} / 32</span>`);
  if (from === 22) {
    html = html.replace(
      '当前优势是 SAP 业务流程的深度；两者可复用工具。灵犀新权限与新引擎仍需按现场部署状态验收。',
      '当前优势是 SAP 业务流程的深度；新引擎已有部分能力在 QAS 联调，具体可用范围以现场配置为准。'
    );
  }
  if (from === 23) {
    html = html.replace(
      '这是灵犀仓库里的受控流程；具体步骤是否已在 SAP 现场上线，需按部署验收确认。',
      '流程示意基于已登记报表；实际可用报表与权限以现场配置为准。'
    );
  }
  await fs.writeFile(path.join(target, `slide_${String(to).padStart(2, '0')}.html`), html);
}

for (let i = 1; i <= 27; i++) await copySlide(i, i);

const s28 = shell(28, `
<div class="eyebrow">ENGINE / TWO WAYS TO RUN</div>
<h1 class="title" style="margin-top:20px">旧引擎与新引擎</h1>
<p class="lead" style="margin-top:19px;max-width:1290px">共用灵犀页面和 SAP 业务能力。区别是模型与工具的循环由谁驱动。</p>
<div style="display:grid;grid-template-columns:280px 1fr;gap:34px;margin-top:42px;align-items:stretch">
  <div style="background:#183D46;color:#fff;padding:24px 30px;min-height:162px"><div class="num" style="color:#80D6DF">OLD ENGINE</div><div style="font-size:42px;font-weight:800;margin-top:20px">SAP 后端</div></div>
  <div style="border-top:4px solid #4D94A0;padding-top:14px"><div style="font-size:31px;font-weight:800">ABAP（SAP 程序）控制步骤</div><div style="font-size:24px;line-height:1.55;color:#55727A;margin-top:12px">沿用已接入的场景、报表和权限流程。适合路径明确的 SAP 任务；复杂编排要在后端逐项开发。</div></div>
</div>
<div style="display:grid;grid-template-columns:280px 1fr;gap:34px;margin-top:26px;align-items:stretch">
  <div style="background:#4D94A0;color:#fff;padding:24px 30px;min-height:162px"><div class="num" style="color:#E9F7F5">NEW ENGINE</div><div style="font-size:42px;font-weight:800;margin-top:20px">浏览器</div></div>
  <div style="border-top:4px solid #4D94A0;padding-top:14px"><div style="font-size:31px;font-weight:800">Deep Agents（执行框架）安排步骤</div><div style="font-size:24px;line-height:1.55;color:#55727A;margin-top:12px">会列计划、逐步调工具，也能用授权文件夹和记忆。每个 SAP 工具仍回后端校验；关掉页面，当前运行会中断。</div></div>
</div>
<div style="position:absolute;bottom:4px;left:0;right:0;border-top:2px solid #183D46;padding-top:13px;font-size:22px;font-weight:700">换引擎不会改变 SAP 用户身份、报表授权和业务执行规则。</div>`);

const s29 = shell(29, `
<div class="eyebrow">ENGINE / SAME TASK</div>
<h1 class="title" style="margin-top:20px">同一项联合分析，两套引擎怎么做</h1>
<div style="background:#183D46;color:#fff;padding:16px 26px;margin-top:27px;font-size:29px;font-weight:700">“两张报表按物料和工厂核对，再补物料组，找出缺口。”</div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:52px;margin-top:46px">
  <div style="border-top:4px solid #4D94A0;padding-top:16px">
    <div style="font-size:34px;font-weight:800">旧引擎</div>
    <div style="font-size:25px;line-height:1.72;margin-top:19px">① 执行已登记报表<br>② 进入组合分析入口<br>③ 在新会话里继续看组合结果</div>
    <div style="border-top:1px solid #B7C9C8;margin-top:21px;padding-top:14px;color:#55727A;font-size:23px">长处：既有流程明确。<br>代价：跨入口交接，追问要带上结果。</div>
  </div>
  <div style="background:#183D46;color:#fff;padding:21px 30px">
    <div style="font-size:34px;font-weight:800">新引擎</div>
    <div style="font-size:25px;line-height:1.72;margin-top:16px">① 同一会话执行报表<br>② 关联结果，再查表补字段<br>③ 围绕联合结果继续追问</div>
    <div style="border-top:1px solid #40636A;margin-top:21px;padding-top:14px;color:#B4D0D1;font-size:23px">长处：多步分析更连贯。<br>代价：页面要保持打开，耗时与调用量需实测。</div>
  </div>
</div>
<div style="position:absolute;bottom:0;left:0;right:0;border-top:2px solid #183D46;padding-top:13px;font-size:20px;line-height:1.35">新引擎同会话联合分析的首批功能已在 QAS（测试库）联调；新旧引擎的同题成功率、耗时尚无完整对比数据。</div>`);

const s30 = shell(30, `
<div class="eyebrow">CLIENT / PAGE AND DESKTOP</div>
<h1 class="title" style="margin-top:20px">页面版与灵犀桌面客户端</h1>
<p class="lead" style="margin-top:17px">差别主要在运行环境。灵犀桌面客户端目前还在规划中。</p>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:50px;margin-top:47px">
  <div style="border-top:4px solid #4D94A0;padding-top:20px">
    <div style="font-size:35px;font-weight:800">页面版 · 现有</div>
    <div style="font-size:26px;line-height:1.58;margin-top:22px">打开 SAP 页面就能用，统一发布更新。<br>沿用本人 SAP 身份和报表流程。<br>可访问用户选定并授权的文件夹。</div>
    <div style="border-top:1px solid #B7C9C8;margin-top:23px;padding-top:14px;color:#55727A;font-size:23px;line-height:1.5">限制：依赖安全连接与浏览器授权；关闭页面会打断当前 Agent 运行。</div>
  </div>
  <div style="background:#183D46;color:#fff;padding:23px 32px">
    <div style="font-size:35px;font-weight:800">桌面版 · 规划中</div>
    <div style="font-size:26px;line-height:1.58;margin-top:19px">可设计更完整的本地文件和应用能力。<br>若做常驻进程，可让长任务离开窗口继续跑。<br>SAP 业务仍由后端按本人权限校验。</div>
    <div style="border-top:1px solid #40636A;margin-top:23px;padding-top:14px;color:#B4D0D1;font-size:23px;line-height:1.5">代价：要解决安装、升级、终端安全和任务恢复。</div>
  </div>
</div>
<div style="position:absolute;bottom:0;left:0;right:0;border-top:2px solid #183D46;padding-top:13px;font-size:21px;font-weight:700">只把网页装进桌面壳，关窗后仍会中断；持续运行需要单独设计。</div>`);

const s31 = shell(31, `
<div class="eyebrow">CLIENT / THREE CHOICES</div>
<h1 class="title" style="margin-top:20px">通用桌面 Agent 放在哪里</h1>
<p class="lead" style="margin-top:17px">按任务选入口。灵犀桌面版是规划方向，不能当成现成功能。</p>
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:32px;margin-top:53px">
  <div style="border-top:4px solid #4D94A0;padding-top:18px"><div class="num">01 / CURRENT</div><div style="font-size:32px;font-weight:800;margin-top:11px">灵犀页面版</div><div style="font-size:24px;line-height:1.53;margin-top:22px">适合查 SAP 数据、跑已登记报表、追问业务结果。</div><div style="color:#55727A;font-size:22px;line-height:1.5;margin-top:20px">优势：免安装、权限链路清楚。<br>限制：页面关闭即中断当前运行。</div></div>
  <div style="background:#183D46;color:#fff;padding:21px 26px"><div class="num" style="color:#80D6DF">02 / PLANNED</div><div style="font-size:32px;font-weight:800;margin-top:11px">灵犀桌面版</div><div style="font-size:24px;line-height:1.53;margin-top:22px">目标是把 SAP 任务与本地文件处理接得更深。</div><div style="color:#B4D0D1;font-size:22px;line-height:1.5;margin-top:20px">潜力：本机能力与长任务。<br>代价：客户端研发和运维。</div></div>
  <div style="border-top:4px solid #4D94A0;padding-top:18px"><div class="num">03 / GENERAL</div><div style="font-size:32px;font-weight:800;margin-top:11px">通用桌面 Agent</div><div style="font-size:24px;line-height:1.53;margin-top:22px">适合本机项目、代码和跨应用操作，具体能力看产品。</div><div style="color:#55727A;font-size:22px;line-height:1.5;margin-top:20px">优势：工具范围广。<br>限制：接 SAP 需另做本人身份与业务授权。</div></div>
</div>
<div style="position:absolute;bottom:0;left:0;right:0;border-top:2px solid #183D46;padding-top:13px;font-size:21px;font-weight:700">三种入口可共用模型和工具；SAP 的报表定义、执行与审计应由同一后端管住。</div>`);

for (const [n, html] of [[28, s28], [29, s29], [30, s30], [31, s31]]) {
  await fs.writeFile(path.join(target, `slide_${String(n).padStart(2, '0')}.html`), html);
}
await copySlide(28, 32);
console.log('Wrote 32 slides with engine and desktop comparisons.');
